# PWA MANIFEST

Opcional files to PWA manifest
